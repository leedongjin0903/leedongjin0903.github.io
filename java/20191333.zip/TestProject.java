package org.javaro.lecture;
import java.util.*;
public class TestProject {
    public static void main(String args[]) {
    ArrayList<Car> carlist = new ArrayList<Car>();
    carlist.add(new Car("현대", "그랜저", "00000001", 10, 10));
    carlist.add(new Car("현대", "베뉴", "00000002", 20, 20));
    carlist.add(new Car("현대", "아이오닉6", "00000003", 10, 50));
    carlist.add(new Car("현대", "투싼", "00000004", 20, 30));

    carlist.add(new Car("기아", "K9", "00000005", 40, 60)); 
    carlist.add(new Car("기아", "쏘렌토", "00000006", 20, 70)); 
    carlist.add(new Car("기아", "레이", "00000007", 20, 20)); 
    carlist.add(new Car("기아", "모닝", "00000008", 10, 40)); 
    carlist.add(new Car("쌍용", "토레스", "00000009", 40, 10));
    carlist.add(new Car("쌍용", "티볼리", "00000010", 50, 60));
    Scanner input = new Scanner(System.in);
    System.out.print("Enter model to rent: ");
    String model = input.nextLine();
    for(Car s : carlist){
        if (model.equals(s.getModel())) {
            System.out.println("모델명  " + model + " 사용할 수 있습니다.");
            System.out.print("며칠 렌트 하시겠습니까?: ");
            int days = input.nextInt();
            System.out.println("****세부사항****");
            int cost = (days * s.getRate()) + s.getDeposit();
            System.out.println("보증금 하루이용료 빌린기간 총비용"); 
            System.out.println(s.getDeposit() + " " + s.getRate()+ " " + days + " " + cost);
            System.out.print("렌트 하시겠습니까?( y/n ): ");
            String dec = input.next();
            if (dec.equals("y")) {
                System.out.println("이름을 입력하세요: "); 
                String name = input.next(); 
                System.out.println("IC번호를 입럭하세요: ");
                int num = input.nextInt();
                System.out.println("***영수증****");
                System.out.println("이름 IC번호 자동차 번호 렌트기간 총비용");
                System.out.println(name + " " + num + " " + model + " " + s.getRegNo() + " " + days + " "+cost);
                System.out.println("다음 고객");
                } 
                else if (dec.equals("n")) {
                    System.out.println("다음 고객: ");
                    } 
                    }
                    }
                    } 
                    }